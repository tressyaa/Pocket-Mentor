package com.example.pocket_mentor

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
